# Responsive Admin Dashboard

This is a responsive admin dashboard built using **HTML 5**, **CSS 3** and **JavaScript**. Charts are built using **ApexCharts 3**.

![plot](https://github.com/BobsProgrammingAcademy/Responsive-Admin-Dashboard/blob/master/images/large.png?raw=true)

## Copyright and License

Copyright © 2022 Bob's Programming Academy. Code released under the MIT license.
